@extends('layouts.app')

@section('title')
Question Bank | Create
@endsection

@section('content')
<div class="bg-light rounded">
    <div class="card">
        <div class="card-body">
            <div class="d-flex">
                <div class="col">
                    <h5 class="card-title">Create</h5>
                    <h6 class="card-subtitle mb-2 text-muted">Create Question section here.</h6>
                </div>
                <div class="justify-content-end">
                    <a href='{{route('question.bank.create')}}' class="btn btn-primary">&#43; Add</a>
                </div>
            </div>
            <div class="mt-2">
                @include('layouts.includes.messages')
            </div>

            <form id="form-question" action="{{ route('question.bank.update',$question->id) }}" method="POST" enctype="multipart/form-data">
                @csrf

                <div id="questions-container">
                    <div class="question-block">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Select Language</label>
                                    <select class="form-control" name="language">
                                        <option @if($question->language == 1) selected @endif value="1">Hindi</option>
                                        <option @if($question->language == 2) selected @endif value="2">English</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Question Type</label>
                                    <select id="question-type"class="form-control" name="question_type">
                                        <option @if($question->question_type == 0) selected @endif value="0">Normal</option>
                                        <option @if($question->question_type == 1) selected @endif value="1">Previous Year</option>
                                         <option @if($question->question_type == 2) selected @endif value="2">Current Affair</option>
                                    </select>
                                </div>
                                <div class="form-group previous-year-group" id="previous-year" style="display: none;">
                                    <label>Previous Year</label>
                                    <input type="number" class="form-control" name="previous_year" placeholder="Ex. 2014">
                                </div>
                                <div class="form-group">
                                    <label>Select Examination Commission</label>
                                    <select class="form-control" name="commission_id" id="exam_com_id">
                                        <option value="">--Select--</option>
                                        @foreach($commissions as $commission)
                                            <option @if($question->commission_id == $commission->id) selected @endif value="{{ $commission->id }}">{{ $commission->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Select Category</label>
                                    <select class="form-control" name="category_id" id="category_id">
                                        <option value="">--Select--</option>
                                        @foreach($categories as $category)
                                            <option @if($question->category_id == $category->id) selected @endif value="{{ $category->id }}">{{ $category->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group sub-cat hidecls" >
                                    <label>Sub Category</label>
                                    <select class="form-control" name="sub_category_id" id="sub_category_id">
                                        <option value="">--Select--</option>
                                        @foreach($categories as $category)
                                            <option @if($question->sub_category_id == $category->id) selected @endif value="{{ $category->id }}">{{ $category->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                               
                                <div class="form-group">
                                    <label>Select Subject</label>
                                    <select class="form-control" name="subject_id" id="subject_id">
                                        <option value="">--Select--</option>
                                        @foreach($subjects as $subject)
                                            <option @if($question->subject_id == $subject->id) selected @endif value="{{ $subject->id }}">{{ $subject->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Select Chapter</label>
                                    <select class="form-control" name="chapter_id" id="chapter_id">
                                        <option value="">--Select--</option>
                                        @foreach($subjects as $chapter)
                                            <option @if($question->chapter_id == $chapter->id) selected @endif value="{{ $chapter->id }}">{{ $chapter->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Select Topic</label>
                                    <select class="form-control" name="topic" id="topic_id">
                                        <option value="">--Select--</option>
                                        @foreach($topics as $topic)
                                            <option @if($question->topic_id == $topic->id) selected @endif value="{{ $topic->id }}">{{ $topic->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-check mt-2">
                                    <input id="has_instruction" @if($question->has_instruction == 1) checked @endif type="checkbox" class="form-check-input has-instruction" name="has_instruction" onchange="toggleInstruction(this)">
                                    <label for="has_instruction">Has an Instruction</label>
                                </div>
                                <div class="form-group instruction-group" @if($question->has_instruction == 0) style="display: none;" @endif >
                                    <textarea class="form-control quill-editor" name="instruction">{{$question->instruction}}</textarea>
                                    <label>Instruction</label>
                                </div>
                                <div class="form-group mt-2">
                                    <input type="checkbox" class="form-check-input has-option-e" @if($question->has_option_e == 1) checked @endif name="has_option_e" onchange="toggleOptionE(this)">
                                    <label>Has option E</label>
                                </div>
                                 <div class="form-group mt-2">
                                    <input type="checkbox" class="form-check-input" @if($question->show_on_pyq == "yes") checked @endif name="show_on_pyq" value="yes">
                                    <label for="show_on_pyq">Show on PYQ</label>
                                </div>
                            </div>
                            <div class="col-md-6" id="question_form">
                                <div class="question-count" class="form-group">
                                    <h4>Question 1</h4>
                                </div>
                                <div class="form-group">
                                    <label>Enter Question</label>
                                    <textarea class="form-control quill-editor1" name="question[]">{{$question->question}}</textarea>
                                </div>
                                <div class="form-group">
                                    <label>Answer</label>
                                    <input type="text" class="form-control" name="answer[]" placeholder="Ex. a" value="{{$question->answer}}">
                                </div>
                                <div class="form-group">
                                    <label>Option A</label>
                                    <textarea class="form-control quill-editor2" name="option_a[]">{{$question->option_a}}</textarea>
                                </div>
                                <div class="form-group">
                                    <label>Option B</label>
                                    <textarea class="form-control quill-editor3" name="option_b[]">{{$question->option_b}}</textarea>
                                </div>
                                <div class="form-group">
                                    <label>Option C</label>
                                    <textarea class="form-control quill-editor4" name="option_c[]">{{$question->option_c}}</textarea>
                                </div>
                                <div class="form-group">
                                    <label>Option D</label>
                                    <textarea class="form-control quill-editor5" name="option_d[]">{{$question->option_d}}</textarea>
                                </div>
                                <div class="form-group option-e-group" @if($question->has_option_e == 0) style="display: none;" @endif >
                                    <label>Option E</label>
                                    <textarea class="form-control quill-editor6" name="option_e[]">{{$question->option_e}}</textarea>
                                </div>
                            </div>
                            <div id="question-clone"></div>
                            {{-- <div class="col-md-12 d-flex justify-content-end mt-2">
                                <button type="button" id="add-more" class="btn btn-secondary mb-3">Add More</button>
                            </div> --}}
                        </div>
                        <hr>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary mb-3">Submit</button>
            </form>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/quill@2.0.2/dist/quill.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>

<script>
       $(document).ready(function() {
    $(document).on('change', '#exam_com_id', function(event) {
            
            $('#category_id').html("");
            $('#subject_id').html("");
            $('#chapter_id').html("");
            $('#topic_id').html("");
            let competitive_commission = $(this).val();
            $.ajax({
                url: `{{ URL::to('fetch-exam-category-by-commission/${competitive_commission}') }}`,
                type: 'GET',
                dataType: 'json',
                success: function(result) {
                    if (result.success) {
                        $('#category_id').html(result.html);
                    } else {
                        toastr.error('error encountered ' + result.msgText);
                    }
                },
            });
        });

        $(document).on('change', '#category_id', function(event) {
            
            $('#sub_category_id').html("");
            let exam_category = $(this).val();
            if(exam_category !='')
            {
                $.ajax({
                url: `{{ URL::to('fetch-sub-category-by-exam-category/${exam_category}') }}`,
                type: 'GET',
                dataType: 'json',
                success: function(result) {
                    if (result.success) {
                        if(result.html !='')
                        {
                            $('#sub_category_id').html(result.html);
                            $('.sub-cat').removeClass('hidecls');
                            $('#sub_category_id').attr("required", true);
                        }
                        else{
                            $('#sub_category_id').val("").trigger('change');
                            $('.sub-cat').addClass('hidecls');
                            $('#sub_category_id').attr("required", false);
                        }
                        
                    } else {
                        toastr.error('error encountered ' + result.msgText);
                    }
                },
                });
            }
            else{
                $('#sub_category_id').val("").trigger('change');
                $('.sub-cat').addClass('hidecls');
                $('#sub_category_id').attr("required", false);
            }
            
        });

        $(document).on('change', '#exam_com_id,#category_id,#sub_category_id', function(e) {
            e.preventDefault(e);

            $('#subject_id').val("").trigger('change');
            let competitive_commission = $('#exam_com_id').val();
            let category_id = $('#category_id').val();
            let sub_category_id = $('#sub_category_id').val();
            $.ajax({
                headers: { "Access-Control-Allow-Origin": "*" },
                url: `{{ URL::to('fetch-subject/${competitive_commission}/${category_id}/${sub_category_id}') }}`,
                type: 'GET',
                dataType: 'json',
                success: function(result) {
                    if (result.success) {
                        $('#subject_id').html(result.html);
                    } else {
                        alert(result.msgText);
                        //toastr.error('error encountered ' + result.msgText);
                    }
                },
            });
        });
        $(document).on('change', '#subject_id', function(event) {
            
            $('#chapter_id').val("").trigger('change');
            let subject = $(this).val();
            if(subject !='')
            {
                $.ajax({
                url: `{{ URL::to('fetch-chapter-by-subject/${subject}') }}`,
                type: 'GET',
                dataType: 'json',
                success: function(result) {
                    if (result.success) {
                        if(result.html !='')
                        {
                            $('#chapter_id').html(result.html);
                        }
                        else{
                            $('#chapter_id').val("").trigger('change');
                        }
                        
                    } else {
                        toastr.error('error encountered ' + result.msgText);
                    }
                },
                });
            }
            else{
                // $('#sub_category_id').val("").trigger('change');
                // $('.sub-cat').addClass('hidecls');
                // $('#sub_category_id').attr("required", false);
            }
            
        });
        $(document).on('change', '#chapter_id', function(event) {
            
            $('#topic_id').val("").trigger('change');
            let chapter = $(this).val();
            if(chapter !='')
            {
                $.ajax({
                url: `{{ URL::to('fetch-topic-by-chapter/${chapter}') }}`,
                type: 'GET',
                dataType: 'json',
                success: function(result) {
                    if (result.success) {
                        if(result.html !='')
                        {
                            $('#topic_id').html(result.html);
                        }
                        else{
                            $('#topic_id').val("").trigger('change');
                        }
                        
                    } else {
                        toastr.error('error encountered ' + result.msgText);
                    }
                },
                });
            }
            
        });
    });
    //  document.addEventListener('DOMContentLoaded', function() {
    //     var quill = new Quill('.quill-editor', {
    //     modules: {
    //         toolbar: [
    //         [{ header: [1, 2, false] }],
    //         ['bold', 'italic', 'underline'],
    //         ['image', 'code-block'],
    //         ],
    //     },
    //     placeholder: 'Compose an epic...',
    //     theme: 'snow', // or 'bubble'
    //     });
    //     var quill1 = new Quill('.quill-editor1', {
    //     modules: {
    //         toolbar: [
    //         [{ header: [1, 2, false] }],
    //         ['bold', 'italic', 'underline'],
    //         ['image', 'code-block'],
    //         ],
    //     },
    //     placeholder: 'Compose an epic...',
    //     theme: 'snow', // or 'bubble'
    //     });
    //     var quill2 = new Quill('.quill-editor2', {
    //     modules: {
    //         toolbar: [
    //         [{ header: [1, 2, false] }],
    //         ['bold', 'italic', 'underline'],
    //         ['image', 'code-block'],
    //         ],
    //     },
    //     placeholder: 'Compose an epic...',
    //     theme: 'snow', // or 'bubble'
    //     });
    //     var quill3 = new Quill('.quill-editor3', {
    //     modules: {
    //         toolbar: [
    //         [{ header: [1, 2, false] }],
    //         ['bold', 'italic', 'underline'],
    //         ['image', 'code-block'],
    //         ],
    //     },
    //     placeholder: 'Compose an epic...',
    //     theme: 'snow', // or 'bubble'
    //     });
    //     var quill4 = new Quill('.quill-editor4', {
    //     modules: {
    //         toolbar: [
    //         [{ header: [1, 2, false] }],
    //         ['bold', 'italic', 'underline'],
    //         ['image', 'code-block'],
    //         ],
    //     },
    //     placeholder: 'Compose an epic...',
    //     theme: 'snow', // or 'bubble'
    //     });
    //     var quill5 = new Quill('.quill-editor5', {
    //     modules: {
    //         toolbar: [
    //         [{ header: [1, 2, false] }],
    //         ['bold', 'italic', 'underline'],
    //         ['image', 'code-block'],
    //         ],
    //     },
    //     placeholder: 'Compose an epic...',
    //     theme: 'snow', // or 'bubble'
    //     });
    //     var quill6 = new Quill('.quill-editor6', {
    //     modules: {
    //         toolbar: [
    //         [{ header: [1, 2, false] }],
    //         ['bold', 'italic', 'underline'],
    //         ['image', 'code-block'],
    //         ],
    //     },
    //     placeholder: 'Compose an epic...',
    //     theme: 'snow', // or 'bubble'
    //     });
    //     const form = document.getElementById('form-question');
    //     form.addEventListener('submit', (event) => {
    //         event.preventDefault(); // Prevent default form submission

    //         // Get Quill content as HTML
    //         const instruction = quill.root.innerHTML;
    //         const question = quill1.root.innerHTML;
    //         const option_a = quill2.root.innerHTML;
    //         const option_b = quill3.root.innerHTML;
    //         const option_c = quill4.root.innerHTML;
    //         const option_d = quill5.root.innerHTML;
    //         const option_e = quill6.root.innerHTML;
            
    //         const hiddenInput1 = document.createElement('input');
    //         const hiddenInput2 = document.createElement('input');
    //         const hiddenInput3 = document.createElement('input');
    //         const hiddenInput4 = document.createElement('input');
    //         const hiddenInput5 = document.createElement('input');
    //         const hiddenInput6 = document.createElement('input');
    //         const hiddenInput7 = document.createElement('input');
    //         hiddenInput1.type = 'hidden';
    //         hiddenInput2.type = 'hidden';
    //         hiddenInput3.type = 'hidden';
    //         hiddenInput4.type = 'hidden';
    //         hiddenInput5.type = 'hidden';
    //         hiddenInput6.type = 'hidden';
    //         hiddenInput7.type = 'hidden';

    //         hiddenInput1.name = 'instruction';
    //         hiddenInput2.name = 'question';
    //         hiddenInput3.name = 'option_a';
    //         hiddenInput4.name = 'option_b';
    //         hiddenInput5.name = 'option_c';
    //         hiddenInput6.name = 'option_d';
    //         hiddenInput7.name = 'option_e';

    //         hiddenInput1.value = instruction;
    //         hiddenInput2.value = question;
    //         hiddenInput3.value = option_a;
    //         hiddenInput4.value = option_b;
    //         hiddenInput5.value = option_c;
    //         hiddenInput6.value = option_d;
    //         hiddenInput7.value = option_e;

    //         // Append the hidden input to the form
    //         form.appendChild(hiddenInput1);
    //         form.appendChild(hiddenInput2);
    //         form.appendChild(hiddenInput3);
    //         form.appendChild(hiddenInput4);
    //         form.appendChild(hiddenInput5);
    //         form.appendChild(hiddenInput6);
    //         form.appendChild(hiddenInput7);

    //         // Submit the form
    //         form.submit();
    //     });
    //  });
     
     document.getElementById('question-type').addEventListener('change', function () {
        var previousYearGroup = document.getElementById('previous-year');
        if (this.value == '1') {
            previousYearGroup.style.display = 'block';
        } else {
            previousYearGroup.style.display = 'none';
        }
    });
    document.getElementById('add-more').addEventListener('click', function () {
        let questionBlock = document.getElementById('question_form');
        let newQuestionBlock = questionBlock.cloneNode(true);
        
        // Update question count
        let count = document.querySelectorAll('.question-block').length + 1;
        newQuestionBlock.querySelector('.question-count').innerHTML = '<h4 class="mt-4">Question ' + count + '</h4>';
        
        // Append the cloned question block
        document.getElementById('question-clone').appendChild(newQuestionBlock);
    });
    function toggleInstruction(checkbox) {
        const instructionGroup = checkbox.closest('.question-block').querySelector('.instruction-group');
        instructionGroup.style.display = checkbox.checked ? 'block' : 'none';
    }

    function toggleOptionE(checkbox) {
        const optionEGroup = checkbox.closest('.question-block').querySelector('.option-e-group');
        optionEGroup.style.display = checkbox.checked ? 'block' : 'none';
    }
</script>
@endsection
