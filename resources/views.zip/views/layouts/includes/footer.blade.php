<footer class="footer text-sm">
    <div>
        <a href="https://webmingo.in">WebMingo</a>.
        Copyright &copy; {{ date('Y') }}
    </div>
</footer>
