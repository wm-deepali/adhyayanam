@include('front.partials.header')
@yield('content')
@include('front.partials.footer')