@extends('layouts.adminmaster')

@section('title')

    Admin : YOGKULAM NO 1 YOGA Teaching

@endsection

@section('header')

    @include('layouts.aheader')

@endsection

@section('content')

@inject('Permission', 'App\PermissionTraitForBlade')
<style>
    .adminbtn-blue, .adminbtn-blue:focus {
    background-color: #dc6b1e;
    color: #fff;
    border-radius: 25px;
    font-family: 'Roboto', sans-serif;
}
</style>
<div class="page-header">

					<div class="row">

						<div class="col-md-12 col-sm-12">

							<div class="title">

								<h4>Add Topic</h4>

							</div>

							<nav aria-label="breadcrumb" role="navigation">

								<ol class="breadcrumb">

									<li class="breadcrumb-item"><a href="/dashboard">Dashboard</a></li>

									<li class="breadcrumb-item active" aria-current="page">Topic</li>

								</ol>

							</nav>

						</div>

					</div>

</div>

<div class="pd-20 card-box mb-30">

   <div class="row">

        <div class="col-sm-4">

           <h4>MANAGE - Topic</h4>

       </div>

       <div class="col-sm-8" style='text-align:right'>

           

                    <a data-action="reload"><i class="ft-rotate-cw"></i> Refresh </a>

                     &nbsp;&nbsp;&nbsp;

                    <a href="javascript:history.go(-1)"><i class="fa fa-backward"></i> Go Back</a>

                     &nbsp;&nbsp;&nbsp;

       </div>

   </div>

</div>

<div class="pd-20 card-box mb-30">
<div class="card-block">

       @include('admin.topic.form', ['topic' => new App\Models\Topic()])
        </div>

</div>

</div>

@endsection

@section('footer')

@include('layouts.afooter')

    
@endsection