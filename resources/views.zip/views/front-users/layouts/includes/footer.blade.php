<footer class="main-footer">
    <div class="pull-right d-none d-sm-inline-block">
        <ul class="nav nav-primary nav-dotted nav-dot-separated justify-content-center justify-content-md-end">
		  <li class="nav-item">
			<p>Design and Developed by WebMingo</p>
		  </li>
		</ul>
    </div>
	  &copy; <script>document.write(new Date().getFullYear())</script>  All Rights Reserved.
  </footer>