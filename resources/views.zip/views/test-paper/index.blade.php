@extends('layouts.app')

@section('title')
Question Bank
@endsection

@section('content')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
    .card-body table th{
        font-size:13px;
    }
</style>

<div class="bg-light rounded">
    <div class="card">
        <div class="card-body">
            <div class="d-flex">
                <div class="col">
                    <h5 class="card-title">Test Paper</h5>
                    <!--<h6 class="card-subtitle mb-2 text-muted"> Manage your Question Bank section here.</h6>-->
                </div>
                <div class="justify-content-end">
                    <a href='{{route('test.paper.create')}}' class="btn btn-primary">&#43; Create New Paper</a>
                </div>
            </div>
            <div class="mt-2">
                @include('layouts.includes.messages')
            </div>
            <div class="table-responsive-lg">
  
            <table class="table table-striped mt-5">
                <thead>
                    <tr>
                        <th scope="col" >Date & Time</th>
                        <th scope="col">Test Code</th>
                        <th scope="col">Test Paper Name</th>
                        <th scope="col">Paper Type</th>
                        <th scope="col">Examination Category</th>
                        <th scope="col">Language</th>
                        <th scope="col">Total Questions</th>
                        <th scope="col">Total Marks</th>
                        <th scope="col">Durations</th>
                        <th scope="col">Status</th>
                        <!--<th scope="col">Total Marks</th>-->
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($test as $bank)
                    <tr>
                       
                        <td>{{$bank->created_at}}</td>
                        <td>{{$bank->test_code}}</td>
                        <td>{{ $bank->name }}</td>
                        <td> {{ $bank->paper_type ==0 ? 'Normal' : ($bank->paper_type ==1 ?'Previous Year' : "Current Affair")}}</td>
                        <td>{{$bank->category->name??"_"}}</td>
                        <td>{{$bank->language??"_"}}</td>
                        <td>{{$bank->total_questions}}</td>
                        <td>{{$bank->total_marks}}</td>
                        <td>{{$bank->duration}}</td>
                        <td>Active</td>
                        <td>
                            {{-- <button class="btn btn-sm btn-primary">View</button> --}}
                            {{-- <button class="btn btn-sm btn-secondary">Edit</button> --}}
                            <form action="{{ route('test.paper.delete', $bank->id) }}" method="POST" style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                            </form>
                           
                            
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>
@endsection