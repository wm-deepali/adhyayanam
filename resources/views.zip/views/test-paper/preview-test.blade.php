<style>
    .exam-paper {
        background: #fff;
        border: 1px solid #ccc;
        padding: 100px 80px;
    }

    .exam-haeding {
        text-align: center;
    }

    .exam-haeding h2 {
        color: #000;
        font-size: 30px;
        font-weight: 700;
        margin-bottom: 40px;
    }

    .exam-haeding h3 {
        color: #000;
        font-size: 28px;
        font-weight: 700;
        margin-bottom: 30px;
    }

    .exam-haeding h4 {
        color: #000;
        font-size: 26px;
        font-weight: 600;
    }

    .time-hours {
        display: flex;
        justify-content: space-between;
    }

    .time-hours h2 {
        font-size: 24px;
        color: #000;
        font-weight: 700;
    }

    .instructions {
        padding: 30px 0;
        border-top: 1px solid #ccc;
    }

    .instructions ol {
        padding-left: 15px;
    }

    .instructions ol li {
        line-height: 24px;
        margin-bottom: 20px;
    }

    .instructions h3 {
        font-size: 24px;
        color: #000;
        font-weight: 600;
    }

    .sections {
        border-top: 1px solid #ccc;
        border-bottom: 1px solid #ccc;
        padding: 25px 0;
        text-align: center;
    }

    .sections h2 {
        font-size: 24px;
        color: #000;
        font-weight: 700;
        margin: 0;
    }

    .intro-information {
        display: flex;
        margin-bottom: 15px;
        align-items: center;
    }

    .intro-information .col-form-label {
        margin-right: 15px;
        font-size: 24px;
        color: #333;
        font-weight: 600;
    }

    .intro-information .form-control {
        width: 200px;
        border-radius: 0;
    }

    .instruction-col {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 25px 0;
    }

    .col-bx {
        width: 55%;
    }

    .col-bx ol {
        padding-left: 15px;
    }

    .col-bx ol li {
        line-height: 24px;
        margin-bottom: 15px;
    }

    .intro-information {
        padding-top: 20px;
        border-bottom: 1px solid #eee;
        padding-bottom: 10px;
    }

    .colt {
        display: flex;
        justify-content: end;
        margin-bottom: 15px;
    }

    .colt .col-form-label {
        margin-right: 15px;
    }

    .colt .form-control,
    .mark {
        width: 40px;
        border-radius: 0;
        padding: 6px 10px;
        text-align: center;
    }

    .instruction-last-border {
        width: 75%;
        margin: 0 auto;
        border-bottom: 1px solid #eee;
    }

    .question-sec {
        padding: 20px 0;
    }

    .qs-col {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
    }

    .qs-col.last {
        margin-bottom: 0;
    }

    .question-head {
        font-size: 16px;
        font-weight: 600;
        margin-bottom: 0;
    }

    .customradio {
        display: block;
        position: relative;
        padding-left: 30px;
        margin-bottom: 0px;
        cursor: pointer;
        font-size: 14px;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
        margin-bottom: 10px;
    }

    .customradio input {
        position: absolute;
        opacity: 0;
        cursor: pointer;
    }

    .checkmark {
        position: absolute;
        top: 0;
        left: 0;
        height: 18px;
        width: 18px;
        background-color: white;
        border-radius: 2%;
        border: 1px solid #BEBEBE;
    }

    .customradio:hover input~.checkmark {
        background-color: transparent;
    }

    .customradio input:checked~.checkmark {
        background-color: white;
        border: 1px solid #BEBEBE;
    }

    /* Create the indicator (the dot/circle - hidden when not checked) */
    .checkmark:after {
        content: "";
        position: absolute;
        display: none;
    }

    /* Show the indicator (dot/circle) when checked */
    .customradio input:checked~.checkmark:after {
        display: block;
    }

    /* Style the indicator (dot/circle) */
    .customradio .checkmark:after {
        top: 0px;
        left: 0px;
        width: 17px;
        height: 17px;
        border-radius: 2%;
        background: #6F42C1;
    }

    /* Custom Radio Button End*/
    .secnd .customradio {
        width: 150px;
        margin-right: 30px;
    }

</style>
<div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Preview</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
        </div>
        <div class="modal-body">
            <div class="exam-paper">
                <div class="exam-haeding">
                    <h2>{{ $testData['name'] }}</h2>
                   
                </div>
                <div class="time-hours">
                    <h2>Time: {{ $testData['duration'] }} minutes</h2>
                    <h2 class="ml-auto">Max. Marks : {{ $testData['total_marks'] }}</h2>
                </div>
                <div class="instructions">
                    @if($testData['test_instruction'])
                    <h3>General Instructions :</h3>
                    <ol>
                        {!! $testData['test_instruction'] !!}
                    </ol>
                    @endif
                </div>
                <div style="margin-left:65%">Positive Mark @if ($testData['has_negative_marks'] == 'yes') Negative Mark @endif</div>
                
                    @php
                        $questions = App\Models\Question::whereIn('id', $testData['non_section_details']['question_ids'])->where('status','Done')->get();
                    @endphp
                    @if (isset($questions) && count($questions) > 0)
                        @foreach ($questions as $question)
                            <div class="sec-instruction preview-questions-container">
                                <div class="instruction-last-border"></div>
                                <div class="question-sec">
                                    <div class="qs-col last question-container-div" question_id='{{ $question->id }}' >

                                            <div>{{ $loop->iteration }}. {!! $question->question !!}</div>
                                        
                                        <input type="text" class="form-control mark positive_mark" placeholder="enter positive marks" value="{{$testData['positive_per_question_marks']}}" style="width: 40px;">
                                        @if ($testData['has_negative_marks'] == 'yes')
                                            <input type="text" class="form-control mark negative_mark"  placeholder="enter negative marks" value="{{$testData['negative_marks_per_question']}}" style="width: 40px;">
                                        @endif
                                    </div>
                                    <label class="customradio"><span class="radiotextsty">i) {!! $question->option_a !!}</span>
                                            <input type="checkbox" name="checkbox" disabled>
                                            <span class="checkmark"></span>
                                        </label>
                                        <label class="customradio"><span class="radiotextsty">ii) {!! $question->option_b !!}</span>
                                            <input type="checkbox" name="checkbox" disabled>
                                            <span class="checkmark"></span>
                                        </label>
                                        <label class="customradio"><span class="radiotextsty">iii) {!! $question->option_c !!}</span>
                                            <input type="checkbox" name="checkbox" disabled>
                                            <span class="checkmark"></span>
                                        </label>
                                        <label class="customradio"><span class="radiotextsty">iv) {!! $question->option_d !!}</span>
                                            <input type="checkbox" name="checkbox" disabled>
                                            <span class="checkmark"></span>
                                        </label>
                                        @if ($question->option_e != '')
                                            <label class="customradio"><span class="radiotextsty">iv) {!! $question->option_e !!}</span>
                                                <input type="checkbox" name="checkbox" disabled>
                                                <span class="checkmark"></span>
                                            </label>
                                        @endif
                                   
                                </div>
                            </div>
                        @endforeach
                    @endif
                
                
            </div>
        </div>
        <div class="modal-footer">
            <div class="text-success" id="total-marks">
            </div>
            <div class="text-danger" id="marks_related-err">
            </div>
            <button type="button" class="btn btn-secondary close1" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary" id='add-test-btn' filter_type='{{ $filter_type }}'>Submit</button>
        </div>
    </div>
</div>
<script>
    $(document).on("click",".close1",function(){
    $(".modal").modal('hide');
})
$(document).ready(function(){
    
    addmark();
})
$(".positive_mark").keyup(function(){
    addmark();
})
function addmark(){
     let total_positive_marks = 0;
    $('.positive_mark').each(function() {
        let value = parseFloat($(this).val()) || 0;
        total_positive_marks += value;
    });
    $("#total-marks").html("Total Marks: "+ Math.round(total_positive_marks))
    
}
</script>
