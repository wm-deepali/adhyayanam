@extends('layouts.app')

@section('title')
Test Series | Create
@endsection
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

@section('content')
<style>
    .question-bank-main-page{
        width:100%;
        height:auto;
        display:grid;
        grid-template-columns:1fr 2fr 1fr;
        gap:10px
    }
    .button-actns-questn {
    text-align: center;
    padding: 107px 0;
}
.button-actns-questn i {
    display: block;
    width: 100%;
    padding: 10px;
    color:#fff;
}
    form {
    display: flex;
    flex-direction: column;
    gap: 20px;
}
.box-questns ul li {
    padding: 2px 10px;
    border-bottom: 1px dashed #ccc;
}
.box-questns {
    border:1px solid gray; 
    border-radius:10px;
}
.box-questns ul {
    padding: 0px;
    list-style: none;
    margin: 0;
    max-height: 300px;
    overflow: auto;
    height: 300px;
}

.form-section {
    border: 1px solid #ccc;
    padding: 20px;
    border-radius: 7px;
    /*background-color: #fafafa;*/
}

label {
    font-weight: bold;
    margin-bottom: 5px;
}

input[type="text"], input[type="number"], input[type="file"], select, textarea {
    width: 100%;
    padding: 8px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

input[type="checkbox"] {
    margin-right: 10px;
}

button {
    padding: 10px 15px;
    background-color: #28a745;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}
.question-bank{
    width:100%;
    height:auto;
    display:flex;
    /*grid-template-columns:1fr 1fr 1fr;*/
    flex-direction:row;
    gap:20px;
    border-top:1px solid gray;
    margin-top:30px;
    padding-top:20px;
}
.hidden{
    display:none;
}
.right-side-question::-webkit-scrollbar{
    display:none;
}
#image-preview {
        width: 100%;
        max-width: 300px;
        height: auto;
    }
</style>
<meta name="csrf-token" content="{{ csrf_token() }}">
<div class="bg-light rounded">
    <div class="card">
        <div class="card-body">
            <div class="d-flex">
                <div class="col">
                    <h5 class="card-title">Create</h5>
                    <h6 class="card-subtitle mb-2 text-muted"> Create Test Series here.</h6>
                </div>
            </div>
            <div class="mt-2">
                @include('layouts.includes.messages')
            </div>
            <form id="test-form" method="POST" action="{{ route('test.series.store') }}" enctype="multipart/form-data">
                @csrf
                <div class="row">
                    <div class="col-md-6">
                       
                            <label>Select Language</label>
                            <select class="form-control" name="language" id="language">
                                <option value="Hindi">Hindi</option>
                                <option value="English">English</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label>Select Examination Commission</label>
                            <select class="form-control" name="exam_com_id" id="exam_com_id">
                                <option value="">--Select--</option>
                                @foreach($commissions as $commission)
                                    <option value="{{ $commission->id }}">{{ $commission->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label>Select Category</label>
                            <select class="form-control" name="category_id" id="category_id">
                                <option value="">--Select--</option>
                                @foreach($categories as $category)
                                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                                @endforeach
                            </select>
                        </div>
                       <div class="col-md-6 sub-cat hidecls">
                        <label for="sub_category_id">Sub Category *</label>
                        <select  name="sub_category_id" id="sub_category_id">
                        </select>
                        <div class="text-danger validation-err" id="sub_category_id-err"></div>

                       </div>
                        <div class="col-md-6">
                            <label for="title" class="form-label">Title</label>
                            <input type="text" class="form-control" name="title" id="title" placeholder="Title" required>
                            <div class="text-danger validation-err" id="title-err"></div>
                        </div>
                        <div class="col-md-6">
                            <label for="title" class="form-label">Slug</label>
                            <input type="text" class="form-control" name="slug"  id="slug" placeholder="Slug" required>
                            
                        </div>
                        <div class="col-md-6">
                            <label for="logo" class="form-label">Upload Logo</label>
                            <input type="file" class="form-control" name="logo" id="image" accept="image/*" required>
                            <img id="image-preview" src="#" alt="Your Image" style="display:none;">
                            <div class="text-danger validation-err" id="logo-err"></div>
                            
                        </div>

                        <div class="col-md-6">
                            <label for="mrp" class="form-label">MRP:</label>
                                <input type="number" class="form-control" id="mrp" name="mrp" >
                                <div class="text-danger validation-err" id="mrp-err"></div>
                        </div>
                        <div class="col-md-6">
                            <label for="discount" class="form-label">Discount (%):</label>
                            <input type="number" class="form-control" id="discount" name="discount" >
                            <div class="text-danger validation-err" id="discount-err"></div>
                        </div>
                        <div class="col-md-6">
                            <label for="offered-price" class="form-label">Offered Price:</label>
                        
                                <input type="text" class="form-control" id="offered-price" name="price" readonly>
                                <div class="text-danger validation-err" id="price-err"></div>
                            
                        </div>

               
                
                
                
                
                <!-- Title -->
                
    
                <!-- Category -->
                
    
                <!-- Total Chapters -->
           {{--     <div class="mb-3">
                    <label for="total_chapter" class="form-label">Total Chapters</label>
                    <input type="number" class="form-control" name="total_chapter" required>
                    @if ($errors->has('total_chapter'))
                        <span class="text-danger text-left">{{ $errors->first('total_chapter') }}</span>
                    @endif
                </div>
                <div class="mb-3">
                    <label for="total_subjects" class="form-label">Total Subjects</label>
                    <input type="number" class="form-control" name="total_subjects" required>
                    @if ($errors->has('total_subjects'))
                        <span class="text-danger text-left">{{ $errors->first('total_subjects') }}</span>
                    @endif
                </div>
                <div class="mb-3">
                    <label for="total_affairs" class="form-label">Total Current Affairs</label>
                    <input type="number" class="form-control" name="total_affairs" required>
                    @if ($errors->has('total_affairs'))
                        <span class="text-danger text-left">{{ $errors->first('total_affairs') }}</span>
                    @endif
                </div>
                <div class="mb-3">
                    <label for="free_tests" class="form-label">Total Free Tests</label>
                    <input type="number" class="form-control" name="free_tests" required>
                    @if ($errors->has('free_tests'))
                        <span class="text-danger text-left">{{ $errors->first('free_tests') }}</span>
                    @endif
                </div> --}} 
                

          {{--      <div class="mb-3">
                    <label for="total_marks" class="form-label">Total Marks</label>
                    <input type="number" class="form-control" name="total_marks" required>
                    @if ($errors->has('total_marks'))
                        <span class="text-danger text-left">{{ $errors->first('total_marks') }}</span>
                    @endif
                </div>

                <div class="mb-3">
                    <label for="duration" class="form-label">Total Duration</label>
                    <input type="number" class="form-control" name="duration" placeholder="ex: 120 Minutes" required>
                    @if ($errors->has('duration'))
                        <span class="text-danger text-left">{{ $errors->first('duration') }}</span>
                    @endif
                </div> --}} 
                
                <div class="col-md-12">
                    <label for="description" class="form-label">Short Description</label>
                  <textarea class="form-control editor" id="short_description" name="short_description"></textarea>
                </div>
                <div class="col-md-12">
                    <label for="description" class="form-label">Content</label>
                    <textarea class="form-control editor" id="content" name="description"></textarea>
                    
                </div>
            </div>
            <div class="form-group row question-selection-part master-question-item">
                <div class="col-sm-12">
                    <div class="tab-pane-generated">
                        <div class="tab-content px-1 pt-1">
                            <div class="tab-pane mcq-tab active" id="mcq-tab" role="tabpanel" aria-labelledby="base-mcq">
                                <div class="customquestiondiv">
                                    <div id="question-rows">
                                        <div class="row question-row">
                                            <div class="col-md-4">
                                                <label>Test Type</label>
                                                <select class="form-control test_type" name="type[]">
                                                    <option value="">Choose...</option>
                                                    <option value="1">Full Test</option>
                                                    <option value="2">Subject Wise</option>
                                                    <option value="3">Chapter Wise</option>
                                                    <option value="4">Topic Wise</option>
                                                    <option value="5">Current Affair</option>
                                                    <option value="6">Previous Year</option>
                                                </select>
                                            </div>
                                            <div class="col-md-4">
                                                <label for="test_generated_by">Test Selections</label>
                                                <select id="test_generated_by" name="test_generated_by[]" class="form-control test_generated_by">
                                                    <option value="">Choose...</option>
                                                    <option value="manual">Manual</option>
                                                    <option value="random">Random</option>
                                                </select>
                                            </div>
                                            
                                            <div class="col-md-4">
                                                <label for="title" class="form-label">No. of Paper</label>
                                                <input type="text" class="form-control total_paper" name="total_paper[]" placeholder="No. of Paper" required>
                                            </div>
                                            
                                            <div class="col-md-5">
                                                <div class="box-area-questions">
                                                    <h4>Your Tests <span id="questioncountmcqshow"></span></h4>
                                                    <div class="box-questns">
                                                        <ul class="selected-questions customquestionselectedbox-mcq" id="customquestionselectedbox-mcq"></ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-2">
                                            
                                                <div class="button-actns-questn">
                                                    <button class="btn btn-primary addquestiontoselected-mcq" type="button" fdprocessedid="49r4zxe"><i class="fa fa-arrow-left"></i></button>
                                                    <i class="fa fa-exchange"></i>
                                                    <button class="btn btn-danger removequestionfromselected-mcq" type="button" fdprocessedid="2x8rl7"><i class="fa fa-arrow-right"></i></button>
                                                </div>
                                            </div>
                                            <div class="col-md-5">
                                                <div class="box-area-questions">
                                                    <h4>All Tests <span id="questioncountshow"></span></h4>
                                                    <div class="box-questns">
                                                        <ul class="customquestionbox-mcq" id="customquestionbox-mcq">
                                                           
                
                         
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 text-right mt-2">
                                                {{-- <button type="button" class="btn btn-danger remove-row">Remove</button> --}}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12 mt-3">
                                        <button type="button" class="btn btn-primary" id="add-row">Add More</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
                <div class="row">
                    <div class="col-md-6">
                       
                    </div>
                    <div class="col-md-2">
                        <button type="button" id="add-test-btn" class="btn btn-primary">Save</button>
                    </div>
                    <div class="col-md-2">
                        <a href="{{ route('test.series.index') }}" class="btn">Back</a>
                    </div>
                   
                    
                </div>
               
            </form>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/quill@2.0.2/dist/quill.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>

<script>
$(document).ready(function(){
    
    
    function calculateOfferedPrice() {
                var mrp = parseFloat($('#mrp').val());
                var discount = parseFloat($('#discount').val());

                if (isNaN(mrp) || isNaN(discount)) {
                    $('#offered-price').val(mrp);
                    return;
                }

                var offeredPrice = mrp - (mrp * (discount / 100));
                $('#offered-price').val(offeredPrice.toFixed(2));
            }

            $('#mrp, #discount').on('input', calculateOfferedPrice);
})
     $(document).ready(function() {
    $('.editor').each(function() {
      CKEDITOR.replace(this);
    });
    $(document).on('click', '.question', function(event) {
            if ($(this).is(":checked")) {
                $(this).parent().parent().parent().addClass('questn-selected');
            } else {
                $(this).parent().parent().parent().removeClass('questn-selected');
            }
        });
  });
  
  $(document).on('click', '.addquestiontoselected-mcq', function(event) {
    const questionRow = $(this).closest('.question-row');
    const selQuestions = questionRow.find('#customquestionbox-mcq li.questn-selected');
    const total = parseInt(questionRow.find(".total_paper").val(), 10);

    if (questionRow.find(".customquestionselectedbox-mcq .question").length + selQuestions.length > total) {
        alert(`You can select a maximum of ${total} questions.`);
        return false;
    }

    let temp = questionRow.find('#customquestionselectedbox-mcq').html();
    let testTemp = '';

    selQuestions.each(function() {
        $(this).removeClass('questn-selected');
        temp += this.outerHTML;
        testTemp += `<li>${$(this).find('span span').text()}</li>`;
        $(this).remove();
    });

    questionRow.find('#customquestionselectedbox-mcq').html(temp);
    $('.slide-menu-mcq').append(testTemp);

    const selectedCount = questionRow.find(".customquestionselectedbox-mcq .question").length;
    // questionRow.find("#questioncountmcqshow").text(`(${selectedCount}/${total})`);
});

$(document).on('click', '.removequestionfromselected-mcq', function(event) {
    const questionRow = $(this).closest('.question-row');
    const selQuestions = questionRow.find('#customquestionselectedbox-mcq li.questn-selected');
    let temp = questionRow.find('#customquestionbox-mcq').html();

    selQuestions.each(function() {
        $(this).removeClass('questn-selected');
        temp += this.outerHTML;
        $(this).remove();
    });

    questionRow.find('#customquestionbox-mcq').html(temp);

    const selectedCount = questionRow.find(".customquestionselectedbox-mcq .question").length;
    const total = parseInt($("#total_questions").val(), 10);
    // questionRow.find("#questioncountmcqshow").text(`(${selectedCount}/${total})`);
});
  $(document).ready(function() {
        $('#title').on('input', function() {
            var title = $(this).val();
            var slug = generateSlug(title);
            $('#slug').val(slug);
        });

        function generateSlug(text) {
            return text
                .toLowerCase()            // Convert to lowercase
                .replace(/[^a-z0-9 -]/g, '') // Remove invalid chars
                .replace(/\s+/g, '-')       // Replace spaces with -
                .replace(/-+/g, '-');       // Replace multiple - with single -
        }
    });
    $('#image').change(function(event) {
                var input = event.target;
                if (input.files && input.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        $('#image-preview').attr('src', e.target.result);
                        $('#image-preview').show();
                    }
                    reader.readAsDataURL(input.files[0]);
                }
            });
  $(document).ready(function() {
        $('#add-row').click(function() {
            // Clone the first question row
            $(this).closest('.master-question-item').find('.text-right').html(`<button type="button" class="btn btn-danger remove-row">Remove</button>`)
            var newRow = $('.question-row:first').clone();

            // Clear the values of the cloned row
            newRow.find('input').val('');
            newRow.find('select').prop('selectedIndex', 0);

            // Append the new row to the container
            $('#question-rows').append(newRow);
        });

        // Delegate the event to dynamically added remove buttons
        $('#question-rows').on('click', '.remove-row', function() {
            // Remove the row
            const length = $(".question-row").length;
            console.log(length)
            if(length == 2){
                $(this).closest('.question-row').remove();
                $('.master-question-item').find('.text-right').html("")
            }else{
                $(this).closest('.question-row').remove();
            }
           
        });
    });
     $(document).on('change', '#exam_com_id', function(event) {
            
            $('#category_id').html("");
            $('#subject_id').html("");
            $('#chapter_id').html("");
            $('#topic_id').html("");
            let competitive_commission = $(this).val();
            $.ajax({
                url: `{{ URL::to('fetch-exam-category-by-commission/${competitive_commission}') }}`,
                type: 'GET',
                dataType: 'json',
                success: function(result) {
                    if (result.success) {
                        $('#category_id').html(result.html);
                    } else {
                        toastr.error('error encountered ' + result.msgText);
                    }
                },
            });
        });

        $(document).on('change', '#category_id', function(event) {
            
            $('#sub_category_id').html("");
            let exam_category = $(this).val();
            if(exam_category !='')
            {
                $.ajax({
                url: `{{ URL::to('fetch-sub-category-by-exam-category/${exam_category}') }}`,
                type: 'GET',
                dataType: 'json',
                success: function(result) {
                    if (result.success) {
                        if(result.html !='')
                        {
                            $('#sub_category_id').html(result.html);
                            $('.sub-cat').removeClass('hidecls');
                            $('#sub_category_id').attr("required", true);
                        }
                        else{
                           
                            $('.sub-cat').addClass('hidecls');
                            $('#sub_category_id').attr("required", false);
                        }
                        
                    } else {
                        toastr.error('error encountered ' + result.msgText);
                    }
                },
                });
            }
            
        });

       
       
        $(document).on('change', '.test_type,.total_paper,.test_generated_by', function(event) {
           
           $(this).attr('disabled', true);
           var btn = $(this)
           var test_generated_by = $(this).closest('.question-row').find('.test_generated_by').val()
           $(".validation-err").html('');
           let total_paper = $(this).closest('.question-row').find('.total_paper').val()
           let formData = new FormData();
           formData.append('language', $('#language').val());
           formData.append('competitive_commission', (typeof $('#exam_com_id').val() == 'undefined') ? '' : $('#exam_com_id').val());
           formData.append('exam_category', (typeof $('#category_id').val() == 'undefined') ? '' : $('#category_id').val());
           formData.append('total_paper', total_paper);
           formData.append('test_type', $(this).closest('.question-row').find('.test_type').val());
           formData.append('test_generated_by', test_generated_by);
           $.ajax({
               headers: {
                   'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
               },
               url: "{{ URL::to('generate-test-paper-by-selections') }}",
               type: 'post',
               processData: false,
               contentType: false,
               dataType: 'json',
               data: formData,
               context: this,
               success: function(result) {
                   if (result.success) {
                       $(this).attr('disabled', false);
                       
                       if (test_generated_by == 'manual') {
                           
                        btn.closest('.question-row').find('.customquestionselectedbox-mcq').html('');
                        btn.closest('.question-row').find('.customquestionbox-mcq').html(result.html);
                           
                       } else {
                        btn.closest('question-row').find('.customquestionbox-mcq').html('');
                        btn.closest('question-row').find('.customquestionselectedbox-mcq').html(result.html);
                           
                       }
                   } else {
                       $(this).attr('disabled', false);
                       if (result.code == 422) {
                           for (const key in result.errors) {
                               $(`#${key}-err`).html(result.errors[key][0]);
                           }
                       } else {
                           toastr.error('error encountered -' + result.msgText);
                       }
                   }
               }
           })
       });  
    $(document).on('click', '#add-test-btn', function(event) {
            $(this).attr('disabled', true);
             for (instance in CKEDITOR.instances) {
                CKEDITOR.instances[instance].updateElement();
            }
            let formData = new FormData($("#test-form")[0]);
             let additionalData = {
            testType: [],
            testSelections: [],
            numPapers: [],
            selectedtestpaper: []
        };

        // Gather additional data from the form
        $('.question-row').each(function() {
            additionalData.testType.push($(this).find('.test_type').val());
            additionalData.testSelections.push($(this).find('.test_generated_by').val());
            additionalData.numPapers.push($(this).find('.total_paper').val());
            let d = []
            $(this).find('.customquestionselectedbox-mcq .question').each(function() {
                d.push($(this).val());
            });
            additionalData.selectedtestpaper.push(d)
        });

        // Append additional data to formData
        formData.append('additionalData', JSON.stringify(additionalData));
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: $("#test-form").attr("action"),
                type: 'post',
                processData: false,
                contentType: false,
                dataType: 'json',
                data: formData,
                context: this,
                success: function(result) {
                    if (result.success) {
                        //toastr.success(result.msgText);
                        window.location = `{{ URL::to('test-series') }}`;
                    } else {
                        $(this).attr('disabled', false);
                        if (result.code == 422) {
                            for (const key in result.errors) {
                                $(`#${key}-err`).html(result.errors[key][0]);
                            }
                        } else {
                            toastr.error('error encountered -' + result.msgText);
                        }
                    }
                }
            })
        });
</script>
@endsection