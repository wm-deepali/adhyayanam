@extends('layouts.app')

@section('title')
Test Series
@endsection

@section('content')
<div class="bg-light rounded">
    <div class="card">
        <div class="card-body">
            <div class="d-flex">
                <div class="col">
                    <h5 class="card-title">Test Series</h5>
                    <h6 class="card-subtitle mb-2 text-muted">Manage your Test Series section here.</h6>
                </div>
                <div class="justify-content-end">
                    <a href='{{ route('test.series.create') }}' class="btn btn-primary">&#43; Add</a>
                </div>
            </div>
            <div class="mt-2">
                @include('layouts.includes.messages')
            </div>
            <table class="table table-striped mt-5" style="width:100%">
                <thead>
                    <tr>
                        <th scope="col">Created At</th>
                        <th scope="col">Language</th>
                        <th scope="col">Title</th>
                        <th scope="col">Comission</th>
                        <th scope="col">Category</th>
                        <th scope="col">SubCategory</th>
                        <th scope="col">Logo</th>
                        <th scope="col">Short Description</th>
                        <th scope="col">Total Test</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($test_series as $test)
                        <tr>
                            <td>{{ $test->created_at }}</td>
                            <td>{{ $test->language }}</td>
                            <td>{{ $test->title }}</td>
                            <td>{{ $test->commission->name  ?? "" }}</td>
                            <td>{{ $test->category->name ?? "" }}</td>
                            <td>{{ $test->subcategory->name ?? "" }}</td>
                            <td><img src="{{asset('storage/'.$test->logo)}}" height="70px" /></td>
                           
                            <td>{!! $test->short_description !!}</td>
                            <td>{{count($test->testseries)}}</td>
                           
                            <td>
                                <!-- Add action buttons here (Edit, Delete, etc.) -->
                                <a href="{{ route('test.series.edit', $test->id) }}" class="btn btn-warning btn-sm">Edit</a>
                                <form action="{{ route('test.series.delete', $test->id) }}" method="POST" style="display:inline;">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
