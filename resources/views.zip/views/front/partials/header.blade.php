<meta charset="utf-8">
  @if (trim($__env->yieldContent('header')))
      @yield('header') 
  @endif
  @php
      $headerSettings = App\Models\HeaderSetting::first();
      $pageCategories = Helper::getPageCategories();
      $examinationCommission = App\Models\ExaminationCommission::with('categories.subCategories')->get();
      
  @endphp
	<meta name="google" content="notranslate">
	<!-- Stylesheets -->
	<style>
	.main-header .main-menu .navigation li ul .dropdown.pyq-sub ul {
	right: 100% !important;
	left: -10rem;
}
	
	</style>
	<link href="{{url('assets/css/bootstrap.css')}}" rel="stylesheet">
	<link href="{{url('assets/css/style.css')}}" rel="stylesheet">
  <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
	<link href="{{url('assets/css/responsive.css')}}" rel="stylesheet">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
	<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@300;400;500;600;700;800&amp;display=swap"rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Titillium+Web:wght@300;400;600;700;900&amp;display=swap"rel="stylesheet">
	<link rel="shortcut icon" href="{{url('images/favicon.svg')}}" type="image/x-icon">
	<link rel="icon" href="{{url('images/favicon.svg')}}" type="image/x-icon">
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

	<!-- Responsive -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
  <!-- Main Header -->
  <header class="main-header">
  <div class="page-wrapper">
  
    <!-- Header Top -->
    <div class="header-top">
      <div class="auto-container d-flex justify-content-between align-items-center flex-wrap">

        <!-- Left Box -->
        <div class="left-box d-flex flex-wrap">
          <ul class="info a">
            <li><a href="#"><span class="icon flaticon-phone-call"></span><span class="m-80">{{$headerSettings->contact_number ?? ""}}</span></a></li>
            <li style="padding: 0px !important;"><span>|</span></li>
            <li><a href="#"><span class="icon flaticon-email"></span><span class="m-80">{{$headerSettings->email_id ?? ""}}</span></a>
            </li>
            <li style="padding: 0px !important;"><span>|</span></li>
            <li style="padding-left: 0px !important;"><a href="#" style="padding-left: 0px !important;"><img
                  src="{{url('images/resource/whatsapp.png')}}" /> <span class="m-80">{{$headerSettings->whatsapp_number ?? ""}}</span></a></li>
          </ul>
        </div>

        <!-- Right Box -->
        <div class="right-box d-flex flex-wrap">

          <div class="lr-box">
            <div class="top-header-login">
              <a href="{{route('neti.corner.index')}}" class="theme-btn btn-style-one"><span class="txt">Adhyayanam Corner</span></a>
            </div>
            <div class="top-header-login">
              <a href="{{route('career')}}" class="theme-btn btn-style-one"><span class="txt">Career</span></a>
            </div>
            <div class="top-header-login">
              <a href="{{route('contact.inquiry')}}" class="theme-btn btn-style-one"><span class="txt">Contact Us</span></a>
            </div>
            <div class="top-header-login">
                @if(auth()->user() && auth()->user()->type == 'student')
                <a href="{{route('user.dashboard')}}" class="theme-btn btn-style-one"><span class="txt"><i class="flaticon-add-user"></i> Dashboard</span></a>
                @else
              <a data-bs-toggle="modal" data-bs-target="#lr" class="theme-btn btn-style-one"><span class="txt"><i class="flaticon-add-user"></i> Sign Up
                  / Sign Up</span></a>
                  @endif
            </div>
          </div>
        </div>
       

      </div>
    </div>

    <!-- Header Lower -->
    <div class="header-lower">

      <div class="auto-container container-fluid">
        <div class="inner-container d-flex justify-content-between align-items-center flex-wrap">
          {{-- $headerSettings->company_logo ?? --}}
          <div class="logo-box">
            <div class="logo"><a href="{{url('/')}}"><img src="{{ url('images/Neti-logo.png')}}" style="width:150px;" alt="" title=""></a></div>
          </div>
          <div class="nav-outer d-flex align-items-center flex-wrap">

            <!-- Mobile Navigation Toggler -->
            <div class="mobile-nav-toggler"><span class="icon flaticon-menu"></span></div>
            <!-- Main Menu -->
            <nav class="main-menu show navbar-expand-md">
              <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                  data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                  aria-label="Toggle navigation">
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                </button>
              </div>

              <div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
                <ul class="navigation clearfix">
                  <li><a href="{{url('/')}}">Home</a></li>
                  <li class="dropdown"><a href="#">Our Institute </a>
                    <ul>
                      <li><a href="{{route('about')}}">About Us</a></li>
                      <li><a href="{{route('our.team.index')}}">Our Team</a></li>
                      <li><a href="{{route('vision.mission')}}">Vision & Mission</a></li>
                    </ul>
                  </li>
                  <li class="dropdown"><a href="#">Courses</a>
                    
                    <ul>
                        @foreach($examinationCommission as $commission)
                          <li class="dropdown"><a href="#">{{$commission->name}}</a>
                              <ul>
                                @foreach($commission->categories as $category)
                                    <li class="dropdown last"><a href="#">{{$category->name}}</a>
                                        <ul>
                                            @foreach($category->subCategories as $subCat)
                                                <li><a href="{{route('courses.filter',$subCat->id)}}">{{$subCat->name}}</a></li>
                                            @endforeach
                                        </ul>
                                    </li>
                                @endforeach
                              </ul>
                          </li>
                       @endforeach
                    </ul>
                   
                  </li>
                  <li class="dropdown"><a href="#">Test Series</a>
                    <ul>
                       @foreach($examinationCommission as $commission)
                        <li class="dropdown"><a href="#">{{$commission->name}}</a>
                            <ul>
                              @foreach($commission->categories as $category)
                                <li class="dropdown last"><a href="#">{{$category->name}}</a>
                                    <ul>
                                        @foreach($category->subCategories as $subCat)
                                            <li><a href="{{route('test-series',['examid' => $commission->id, 'catid' => $category->id, 'subcat' => $subCat->id])}}">{{$subCat->name}}</a></li>
                                        @endforeach
                                    </ul>
                                </li>
                              @endforeach
                            </ul>
                        </li>
                      @endforeach
                    </ul>
                  </li>
                  <li><a href="{{route('current.index')}}">Current Affairs</a></li>
                  <li class="dropdown pyq"><a href="#">PYQ</a>
                  <ul>
                    
                      @foreach($examinationCommission as $commission)
                        <li class="dropdown pyq-sub"><a href="#">{{$commission->name}}</a>
                            <ul>
                              @foreach($commission->categories as $category)
                                <li class="dropdown last pyq-last"><a href="#">{{$category->name}}</a>
                                    <ul>
                                        @foreach($category->subCategories as $subCat)
                                            <li><a href="{{route('pyq-papers',['examid' => $commission->id, 'catid' => $category->id, 'subcat' => $subCat->id])}}">{{$subCat->name}}</a></li>
                                        @endforeach
                                    </ul>
                                </li>
                              @endforeach
                            </ul>
                        </li>
                      @endforeach
                      
                   
                      
                    </ul>
                  </li>
                  <li class="dropdown"><a href="#">Student Corner</a>
                    <ul>
                      <li><a href="{{route('study.material.front')}}">Study Material</a></li>
                      <li><a href="{{route('daily.boost.front')}}">Daily Booster</a></li>
                      <li><a href="{{route('test.planner.front')}}">Test Planner</a></li>
                    </ul>
                  </li>

                  <!-- <li>
                    <div class="lr-box">
                      <div class="top-header-login">
                        <a href="#" class="theme-btn btn-style-one"><span class="txt">Test
                            Series</span></a>
                      </div>
                      <div class="top-header-login">
                        <a href="#" class="theme-btn btn-style-one"><span class="txt">Study
                            Material</span></a>
                      </div>
                      <div class="top-header-login">
                        <a href="#" class="theme-btn btn-style-one"><span class="txt">Test
                            Planners</span></a>
                      </div>
                    </div>
                  </li> -->
                </ul>
              </div>

            </nav>
            <!-- Main Menu End-->

            <!-- Outer Box -->
            <!-- <div class="outer-box d-flex flex-wrap">
              <div class="top-header-login">
                <a href="#" class="theme-btn btn-style-one"><span class="txt"><i class="flaticon-add-user"></i> Sign
                    Up</span></a>
              </div>

            </div> -->
            <!-- End Outer Box -->

          </div>
        </div>

      </div>
    </div>
    <!-- End Header Lower -->

    <!-- Sticky Header  -->
    <div class="sticky-header">
      <div class="container d-flex justify-content-between align-items-center flex-wrap">
        <!-- Logo -->
        <div class="logo">
          <a href="{{url('/')}}" title=""><img src="{{url('images/Neti-logo.png')}}" style="width:150px;" alt="Adhyayanam Logo" title=""></a>
        </div>

        <!-- Main Menu -->
        <nav class="main-menu">
          <!--Keep This Empty / Menu will come through Javascript-->
        </nav><!-- Main Menu End-->

        <!-- Mobile Navigation Toggler -->
        <div class="mobile-nav-toggler"><span class="icon flaticon-menu"></span></div>
      </div>
    </div><!-- End Sticky Menu -->

    <!-- Mobile Menu  -->
    <div class="mobile-menu">
      <div class="menu-backdrop"></div>
      <div class="close-btn"><span class="icon flaticon-cancel"></span></div>

      <nav class="menu-box">
        <div class="nav-logo"><a href="index-2.html"><img src="{{url('images/logo.png')}}" alt="" title=""></a></div>
        <div class="menu-outer">
          <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
        </div>
      </nav>
    </div><!-- End Mobile Menu -->

  </header>
  <!-- Bottom header  -->
  @php
    $marquees = App\Models\Marquee::all();
  @endphp
  <div class="bottom-header">
    <div class="container">
      <div class="maq-container">
        <div class="latest-head">
          <span>LATEST NEWS :</span>
        </div>
        <div class="marq-info">
          <marquee class="mar" width="90%" direction="left" onmouseover="this.stop();" onmouseout="this.start();">
            @foreach($marquees as $key=>$data)
                <a style="text-decoration:none;color:white;" href="{{$data->link}}">{{$data->title}},</a>
            @endforeach
          </marquee>
        </div>
      </div>
    </div>
  </div>